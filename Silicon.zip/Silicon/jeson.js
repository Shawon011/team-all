$(document).ready(function(){
    $('.dropdown1').hover(function(){
        $('.sub-menu').stop().fadeToggle();
    }, function(){
        $('.sub-menu').stop().fadeToggle();
    })
})

$(document).ready(function(){
    $('.dropdown2').hover(function(){
        $('.sub-menu1').stop().fadeToggle();
    }, function(){
        $('.sub-menu1').stop().fadeToggle();
    })
})
$(document).ready(function(){
    $('.dropdown3').hover(function(){
        $('.sub-menu2').stop().fadeToggle();
    }, function(){
        $('.sub-menu2').stop().fadeToggle();
    })
})


// Hero section Start
$(document).ready(function(){
    $(window).scroll(function(){
        var scroll_positon = $(window).scrollTop();
        $(".hero-backgroun-img").css({
            "background-position-y" : - scroll_positon + "5px",
        })
    })
});